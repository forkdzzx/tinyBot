# Jarvis 眼神设计交付包 v0.3

从[交付指南](docs/jarvis-eyes-handoff.md)开始。解压后可直接打开[交互预览](prototypes/eyes-design/index.html)，或用[帧导出页](design/eyes/export-frame.html)为显示驱动准备 PNG 和 RGB565。

开发者可运行 `node --test tests/eye-handoff.test.mjs` 和 `node design/eyes/export.mjs check`。需要本地 HTTP 服务时运行 `npm run eyes:preview`。项目验收历史可在完整工程中查看。
